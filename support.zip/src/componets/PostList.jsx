import React, { useState, useEffect } from 'react';
import axios from 'axios';
import PostCard from '../PostCard';
import { Container, CircularProgress } from '@mui/material';

const PostList = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(response => {
        setPosts(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('There was an error fetching the posts!', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Container style={{ textAlign: 'center', marginTop: 50 }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container style={{ marginTop: 20 }}>
      {posts.map(post => (
        <PostCard key={post.id} post={post} />
      ))}
    </Container>
  );
};

export default PostList;
