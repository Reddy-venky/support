import React from 'react';
import { Container, Typography } from '@mui/material';
import PostList from './componets/PostList';

const App = () => {
  return (
    <Container>
      <Typography variant="h3" component="h1" gutterBottom>
        Posts
      </Typography>
      
      <PostList />
    </Container>
  );
};

export default App;
