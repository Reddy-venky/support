import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const PostCard = ({ post }) => {
  return (
    <Card style={{ marginBottom: 20 }}>
      <CardContent>
        <Typography variant="h5" component="div">
          {post.title}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          
          {post.body}
        </Typography>
      </CardContent>
    </Card>
  );
};

export default PostCard;
